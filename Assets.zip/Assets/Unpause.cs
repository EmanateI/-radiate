using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unpause : MonoBehaviour
{
    public int n = 1;
    public GameObject Button;
    // Start is called before the first frame update
    public void UnPause()
    {
        gameObject.SetActive(false);
        Button.SetActive(false);
        Time.timeScale = n;
    }
}
