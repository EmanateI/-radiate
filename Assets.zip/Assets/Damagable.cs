using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Damagable : MonoBehaviour
{
    public double Health;
    public double Healthlook;
    public GameObject Drop;
    public int time;
    public int loot;
    public int n = 10;
    public SpriteRenderer sr;
    void Start()
    {
        Healthlook = n;
        Health = n;
        sr = gameObject.GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (Time.timeScale != 0)
        {
            time++;
            if (time >= 5000)
            {
                Health = Health + time / 1000;
                time = 0;
                Healthlook = Health;
            }
        }
        if (Health <= 0)
        {
            Instantiate(Drop, gameObject.transform.position,Quaternion.identity);
            Destroy(gameObject);
        }
        if (Health < Healthlook)
        {
            sr.material.color = new Color(1, 0, 0);
        }
    }
    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Arrow")
        {
            Health = Health - 20;
        }
        if (collision.gameObject.tag == "Weak")
        {
            Health = Health - 1.5;
        }
    }
}
