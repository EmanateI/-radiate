using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField] private Transform playerTransf;
    [SerializeField] private float movespeed;
    [SerializeField] private string PlayerTag;
    private void Awake()
    {
        if (playerTransf == null)
        {
            if (this.PlayerTag == "")
            {
                this.PlayerTag = "Player";
            }
            this.playerTransf = GameObject.FindGameObjectWithTag(this.PlayerTag).transform;
        }
        this.transform.position = new Vector3()
        {
           x = this.playerTransf.position.x,
           y = this.playerTransf.position.y,
           z = this.playerTransf.position.z - 10,
        };
        
    }
    private void Update()
    {
        if (this.playerTransf)
        {
            Vector3 Target = new Vector3()
            {
                x = this.playerTransf.position.x,
                y = this.playerTransf.position.y,
                z = this.playerTransf.position.z - 10,
            };
            Vector3 pos = Vector3.Lerp(a: this.transform.position, b: Target,t: this.movespeed = Time.deltaTime);
            this.transform.position = pos;
        }
    }
}
