using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damagable1 : MonoBehaviour
{
    public double Health;
    public double Healthlook;
    public int time;
    public int loot;
    public SpriteRenderer sr;
    void Start()
    {
        Healthlook = 10;
        Health = loot;
        sr = gameObject.GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
        if (Health < Healthlook)
        {
            sr.material.color = new Color(1, 1, 1, 0);
        }
    }
    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Arrow")
        {
            Health = Health - 20;
        }
        if (collision.gameObject.tag == "Weak")
        {
            Health = Health - 1.5;
        }
    }
}