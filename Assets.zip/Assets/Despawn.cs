using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Despawn : MonoBehaviour
{
    public int Count;
    private void Update()
    {
        if (Time.timeScale != 0)
        {
            Count++;
            if (Count > 900)
                Destroy(gameObject);
        }
    }
}
