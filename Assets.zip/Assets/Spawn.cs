using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject Template;
    public GameObject Template1;
    public GameObject Template2;
    public float off;
    public float off1;
    public int time;
    public float timecheck;
    public int count;
    public int n = 500;
    // Start is called before the first frame update
    void Start()
    {
        Template1 = Template2;
        off = 0;
        off1 = 0;
    }

    // Update is called once per frame
    void Update()
    {
        timecheck = Time.deltaTime;
        if (timecheck != 0)
        {
            timecheck = 0;
            if (Template != null)
            {
                time++;
                count++;
                if (time >= n)
                {
                    time = 0;
                    off = Random.Range(-155, 190);
                    off1 = Random.Range(-155, 170);
                    float Posx = off;
                    float Posy = off1;
                    Vector3 Plase = new Vector3(Posx, Posy, 0);
                    Instantiate(Template1, Plase, Quaternion.identity);
                }
            }
        }
    }
}
