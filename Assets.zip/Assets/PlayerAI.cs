using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering.VirtualTexturing;
public class PlayerAI : MonoBehaviour
{
    public float Speed;
    public float DirectionX, DirectionY;
    public int Counter;
    public int n;
    public int unlock;
    public int loot;
    public int level;
    public int need4level;
    public int XP;
    public double Refresh;
    public double Cooldown;
    public double Cooldown1;
    public double Defence;
    public Camera Camera;
    public double Shield;
    public double Regen;
    public int MaxShield;
    public TextMeshProUGUI text;
    public TextMeshProUGUI text1;
    public TextMeshProUGUI text2;
    public TextMeshProUGUI text3;
    public TextMeshProUGUI text4;
    public TextMeshProUGUI text5;
    public TextMeshProUGUI text6;
    public TextMeshProUGUI text7;
    public TextMeshProUGUI text8;
    public SpriteRenderer sr;
    public GameObject Arrow;
    public GameObject LVLObj;
    public GameObject Buttonpause;
    public GameObject WeakArrow;
    public Camera cam;
    public Rigidbody2D rb;
    // Start is called before the first frame update
    public void Start()
    {
        LVLObj.SetActive(false);
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        Speed = 5;
        Counter = 0;
        Shield = 100;
        MaxShield = 100;
        Regen = 0.001;
        Defence = 1;
        n = 1;
        level = 1;
        Refresh = 1;
        Death();
        Time.timeScale = n;
        need4level = 100;
    }
    public void Update()
    {
        if (Time.timeScale != 0)
        {
            if (Shield < MaxShield)
            {
                Shield = Shield + Regen;
            }
        }
        if (XP >= need4level)
        {
            level++;
            need4level = need4level + need4level / 100 * 15;
            XP = 0;
            LVLObj.SetActive(true);
            Time.timeScale = 0;
            Buttonpause.SetActive(false);
        }
        text.text = Shield.ToString("F0");
        text1.text = Counter.ToString();
        text2.text = level.ToString();
        text3.text = MaxShield.ToString();
        text4.text = Defence.ToString();
        text5.text = Regen.ToString();
        text6.text = Refresh.ToString();
        text7.text = need4level.ToString();
        text8.text = Speed.ToString();
        Move();
        XP = XP + loot;
    }
    void Move()
    {
        DirectionX = Input.GetAxis("Horizontal");
        DirectionY = Input.GetAxis("Vertical");
        Vector2 movement = new Vector2(DirectionX, DirectionY);
        transform.Translate(movement * Speed * Time.deltaTime);
        if (DirectionX < 0)
        {
            sr.flipX = true;
        }
        if (DirectionX > 0)
        {
            sr.flipX = false;
        }
        // �� ��������!
        // if (Input.GetKeyDown(KeyCode.LeftShift) & Input.GetKeyDown(KeyCode.W))
        //{
        //    rb.AddForce(Vector2.up * 50f * 2f, ForceMode2D.Impulse);
        //}
        //if (Input.GetKeyDown(KeyCode.LeftShift) & Input.GetKeyDown(KeyCode.A))
        //{
        //    rb.AddForce(Vector2.left * 50f * 2f, ForceMode2D.Impulse);
        //}
        //if (Input.GetKeyDown(KeyCode.LeftShift) & Input.GetKeyDown(KeyCode.D))
        //{
        //    rb.AddForce(Vector2.right * 50f * 2f, ForceMode2D.Impulse);
        //}
        //if (Input.GetKeyDown(KeyCode.LeftShift) & Input.GetKeyDown(KeyCode.S))
        //{
        //    rb.AddForce(Vector2.down * 50f * 2f, ForceMode2D.Impulse);
        //}
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
        if (Time.timeScale > 0)
        {
            Cooldown = Cooldown - Refresh;
            if (Cooldown <= 0)
            {


                if (Input.GetMouseButton(0))
                {
                    GameObject newArrow = Instantiate(Arrow) as GameObject;
                    newArrow.AddComponent<Despawn>();
                    newArrow.transform.position = this.transform.position;
                    Rigidbody2D rb2 = newArrow.GetComponent<Rigidbody2D>();
                    if (this.transform.localScale.x > 0)
                    {
                        Vector3 diference = Camera.ScreenToWorldPoint(Input.mousePosition) - transform.position;
                        float rotateZ = Mathf.Atan2(diference.y, diference.x) * Mathf.Rad2Deg;
                        newArrow.transform.rotation = Quaternion.Euler(0f, 0f, rotateZ - 90);
                        rb2.AddForce(diference * 3, ForceMode2D.Impulse);
                        Cooldown = 400;
                    }
                }
            }
            if (unlock != 0)
            {
                Cooldown1 = Cooldown1 - 0.1;
                if (Cooldown1 <= 0)
                {
                    if (Input.GetKey(KeyCode.F))
                    {
                        GameObject newArrow1 = Instantiate(WeakArrow) as GameObject;
                        newArrow1.AddComponent<Despawn>();
                        newArrow1.transform.position = this.transform.position;
                        Rigidbody2D rb2 = newArrow1.GetComponent<Rigidbody2D>();
                        if (this.transform.localScale.x > 0)
                        {
                            Vector3 diference = Camera.ScreenToWorldPoint(Input.mousePosition) - transform.position;
                            float rotateZ = Mathf.Atan2(diference.y, diference.x) * Mathf.Rad2Deg + Random.Range(-50, 50);
                            newArrow1.transform.rotation = Quaternion.Euler(0f, 0f, rotateZ - 90);
                            rb2.AddForce(diference * 3, ForceMode2D.Impulse);
                            Vector2 rand = new Vector2(Random.Range(-50, 50), Random.Range(-50, 50));
                            rb2.AddForce(rand, ForceMode2D.Impulse);
                            Cooldown1 = 0.5;
                        }
                    }
                }
            }
        }
        
    }
    private void OnTriggerEnter2D(Collider2D collectable)
    {
        if (collectable.gameObject.tag == "Coin")
        {
            Destroy(collectable.gameObject);
            Counter++;
        }
        if (collectable.gameObject.tag == "Drop")
        {
            Destroy(collectable.gameObject);
            XP = XP + 10;
        }
        if (collectable.gameObject.tag == "Defence")
        {
            Destroy(collectable.gameObject);
            Defence = Defence + 0.1;
        }
        if (collectable.gameObject.tag == "Shield")
        {
            Destroy(collectable.gameObject);
            Shield = Shield + 20;
            MaxShield = MaxShield + 20;
        }
        if (collectable.gameObject.tag == "Refresh")
        {
            Destroy(collectable.gameObject);
            Refresh = Refresh + 0.1;
        }
        if (collectable.gameObject.tag == "None")
        {
            Destroy(collectable.gameObject);
        }
        if (collectable.gameObject.tag == "Speed")
        {
            Destroy(collectable.gameObject);
            Speed++;
        }
        if (collectable.gameObject.tag == "Regen")
        {
            Destroy(collectable.gameObject);
            Regen = Regen + 0.001;
        }
    }
    void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            Shield = Shield - 5 / Defence;
        }
        if (Shield <= 0)
        {
            Death();
        }
    }    
    public void Death() 
    {
        unlock = 0;
        need4level = 100;
        level = 1;
        Speed = 5;
        XP = 0;
        Counter = 0;
        Shield = 100;
        MaxShield = 100;
        Regen = 0.001;
        Defence = 1;
        Refresh = 1;
        gameObject.transform.position = Vector3.zero;
    }
    public void lvlup()
    {
        unlock = 1;
        Speed++;
        Shield = Shield + 10;
        Regen = Regen + 0.001;
        LVLObj.SetActive(false);
        Time.timeScale = 1;
        Buttonpause.SetActive(true);
    }
}