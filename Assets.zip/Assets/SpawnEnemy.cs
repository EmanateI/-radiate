using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    public GameObject Template1;
    public float off;
    public float off1;
    public int time;
    public float timecheck;
    public int count;
    public
    // Start is called before the first frame update
    void Start()
    {
        off = 0;
        off1 = 0;
    }

    // Update is called once per frame
    void Update()
    {
        timecheck = Time.deltaTime;
        if (timecheck != 0)
        {
            timecheck = 0;
                time++;
                count++;
                if (time >= 750)
                {
                    time = 0;
                    off = Random.Range(-155, 190);
                    off1 = Random.Range(-155, 170);
                    float Posx = off;
                    float Posy = off1;
                    Vector3 Plase = new Vector3(Posx, Posy, 0);
                    Instantiate(Template1, Plase, Quaternion.identity);
                }
            
        }
    }
}
