using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour
{
    public Transform Target;
    public float Speed;
    public float RelaxDistance;
    public int time;
    public float time1;
    public int visible;
    public AnimationCurve curve;
    void Update()
    {
        Speed = curve.Evaluate(time1);
        if (time1 > 1)
        {
            time1 = 0;
        }
        if (Time.timeScale > 0)
        {
            time++;
            time1 = time1 + Time.deltaTime;
            var dir = Target.position - transform.position;
            if (dir.sqrMagnitude > RelaxDistance * RelaxDistance)
            {
                float step = Speed * 3 * Time.deltaTime;
                transform.position = Vector3.MoveTowards(transform.position, Target.position, step);
            }
            if (visible == 1)
            {
                if (time <= 1000)
                {
                    Destroy(gameObject);
                }
            }

        }
    }
    private void OnBecameVisible()
    {
        visible = 1;
    }
}

