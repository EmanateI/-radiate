using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow1 : MonoBehaviour
{
    public Transform Target;
    public float Speed;
    public float RelaxDistance;
    public int time;
    public int time1;
    public int visible;

    void Update()
    {
        if (Time.timeScale > 0)
        {
            time++;
            var dir = Target.position - transform.position;
            if (dir.sqrMagnitude > RelaxDistance * RelaxDistance)
            {
                float step = Speed * Time.deltaTime;
                transform.position = Vector3.MoveTowards(transform.position, Target.position, step);
            }
            if (visible == 1)
            {
                if (time <= 1000)
                {
                    Destroy(gameObject);
                }
            }

        }
    }
    private void OnBecameVisible()
    {
        visible = 1;
    }
}